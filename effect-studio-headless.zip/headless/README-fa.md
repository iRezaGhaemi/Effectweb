# 🧩 فرانت‌اند Headless — استودیو اثر (Next.js + وردپرس REST API)

این یک فرانت‌اند **Next.js** است که محتوا را به‌صورت زنده از وردپرس می‌خواند.
شما در پیشخوان وردپرس محتوا را ویرایش می‌کنید و سایت فوراً به‌روز می‌شود.

## معماری

```
وردپرس (backend)          REST API                Next.js (این پروژه)
───────────────          ───────────             ─────────────────────
برگه‌ها (Pages)    ───►  /wp-json/wp/v2/pages   ───►  صفحه اصلی، درباره ما، ...
نوشته‌ها (Posts)   ───►  /wp-json/wp/v2/posts   ───►  بلاگ و نوشته‌ها
محصولات (ووکامرس)  ───►  /wp-json/wc/v3/products ───►  فروشگاه و محصولات
تصاویر (Media)     ───►  URL مستقیم             ───►  تصاویر
```

## 🚀 اجرای محلی (توسعه)

```bash
cd wordpress/headless
npm install
cp .env.example .env.local   # و آدرس وردپرس را در آن بگذارید
npm run dev
```

بدون تنظیم `.env.local` هم پروژه کار می‌کند و از محتوای جایگزین (fallback) که از
فایل‌های HTML اصلی استخراج شده استفاده می‌کند — برای پیش‌نمایش.

## 🔌 اتصال به وردپرس

1. در `.env.local` بنویسید:

```
NEXT_PUBLIC_WP_URL=https://example.com
```

2. (برای ووکامرس) کلیدهای REST را هم بگذارید:

```
NEXT_PUBLIC_WC_CONSUMER_KEY=ck_xxx
NEXT_PUBLIC_WC_CONSUMER_SECRET=cs_xxx
```

3. سایت را build و deploy کنید:

```bash
npm run build
npm run start
```

به محض اتصال، نشانگر پایین صفحه از «حالت پیش‌نمایش» به «متصل به وردپرس» تغییر می‌کند.

## 📝 چطور محتوا را در وردپرس ویرایش کنید؟

- **برگه‌ها:** در وردپرس برگه‌ای با همان اسلاگ بسازید (مثلاً `about-us`)، محتوا را
  در ویرایشگر بنویسید. عنوان و متن به‌صورت خودکار نمایش داده می‌شود.
- **نوشته‌ها (بلاگ):** نوشته جدید بسازید؛ در صفحه بلاگ و صفحه تکی نوشته نمایش داده می‌شود.
- **محصولات:** با ووکامرس محصول بسازید؛ در فروشگاه نمایش داده می‌شود.

### فیلدهای ساختاری (اختیاری با ACF)

برای بخش‌هایی مثل «هیرو»، «خدمات» و «آمار» که ساختاری هستند، افزونه رایگان
**ACF (Advanced Custom Fields)** را نصب کنید.

> ✅ ما پلاگین ACF و گروه‌های فیلد آماده را برایتان ساخته‌ایم — در
> پوشه `../plugins/`:
> - `advanced-custom-fields.zip` ← پلاگین قابل نصب
> - `acf-field-groups.json` ← گروه‌های فیلد (ایمپورت از Custom Fields → Tools)
>
> کد فرانت‌اند (`lib/wp.js`) این فیلدها را از کلید `acf` در پاسخ REST می‌خواند.

| صفحه | اسلاگ | فیلدهای ACF |
|---|---|---|
| خانه | home | hero_title, hero_subtitle, services, stats, why |
| درباره ما | about-us | hero_text, body |
| آکادمی | academy | hero_text, body, courses |
| دوره | course | hero_text, body, curriculum |

> برای اینکه ACF در REST API در دسترس باشد، در تنظیمات گروه فیلد،
> «Show in REST API» را فعال کنید (در فایل JSON ما از قبل فعال است).

## ⚙️ نکات فنی

- **ISR:** صفحات با `revalidate: 60` ساخته می‌شوند؛ یعنی بعد از ویرایش در وردپرس،
  حداکثر ۶۰ ثانیه بعد سایت به‌روز می‌شود (بدون rebuild دستی).
- **RTL:** کل پروژه راست‌چین است و فونت وزیرمتن به‌صورت محلی در `public/fonts/` قرار دارد.
- **رنگ‌ها:** پالت برند در `styles/globals.css` (متغیرهای CSS).

## 📦 استقرار

### روش ۱ — Docker (توصیه‌شده)

یک `Dockerfile` چندمرحله‌ای و `docker-compose.yml` آماده است:

```bash
# با docker-compose
docker compose up -d --build

# یا دستی
docker build -t effect-studio-headless .
docker run -p 3000:3000 --env-file .env effect-studio-headless
```

آدرس وردپرس را قبل از build در فایل `.env` (یا `--build-arg NEXT_PUBLIC_WP_URL=...`) تنظیم کنید.

> خروجی `standalone` در `next.config.js` فعال است، بنابراین ایمیج نهایی سبک و سریع است.

### روش ۲ — Vercel / Netlify

این پروژه را مستقیم از مخزن import کنید (پلتفرم‌ها Next.js را خودکار تشخیص می‌دهند).

### روش ۳ — سرور Node

```bash
npm run build && npm run start
```
